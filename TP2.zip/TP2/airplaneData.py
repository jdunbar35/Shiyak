# file: airplaneData.py
# author: Jack Dunbar
# date: 11/26/2017
# Initializes airportMap and fills it will all necessary data

# all data is taken from http://www.rita.dot.gov/bts/airfares

from csv import *
from airportMap import *
#import requests
#from bs4 import BeautifulSoup


def getData():
    dataDict = {}

    Airports1 = open('data/2million.csv', 'r')
    data1 = reader(Airports1)
    for row in data1:
        dataDict[row[1]] = int(row[2])

    Airports2 = open('data/1million.csv', 'r')
    data2 = reader(Airports2)
    for row in data2:
        dataDict[row[1]] = int(row[2])

    Airports3 = open('data/1.5million.csv', 'r')
    data3 = reader(Airports3)
    for row in data3:
        dataDict[row[1]] = int(row[2])

    Airports4 = open('data/500k.csv', 'r')
    data4 = reader(Airports4)
    #for row in data4:
        #dataDict[row[1]] = int(row[2])

    return dataDict

def getLocations():
    locationDict = {'Los Angeles, CA': (102, 442),
                    "Chicago O'Hare, IL": (739, 283),
                    'Atlanta, GA': (839, 489),
                    'Denver, CO': (401, 338),
                    'San Francisco, CA': (39, 324),
                    'Boston, MA': (1066, 210),
                    'Seattle/Tacoma, WA': (114, 62),
                    'Philadelphia, PA': (1002, 291),
                    'Minneapolis/St. Paul, MN': (636, 208),
                    'Baltimore, MD': (978, 317),
                    'Ft. Lauderdale, FL': (961, 683),
                    'Detroit, MI': (834, 256),
                    'Washington Reagan, VA': (970, 332),
                    'San Diego, CA': (114, 476),
                    'Portland, OR': (90, 120),
                    'Houston Bush, TX': (602, 614),
                    'Tampa, FL': (899, 637),
                    'Chicago Midway, IL': (746, 282),
                    'Dallas-Fort Worth, TX': (571, 540),
                    'Newark-Liberty, NJ': (1015, 270),
                    'New York JFK, NY': (1022, 269),
                    'New York LaGuardia, NY': (1023, 265),
                    'Phoenix, AZ': (233, 479),
                    'Orlando, FL': (927, 620),
                    'Las Vegas, NV': (177, 405)}

    return locationDict

def createConnections(airportMap):
    # WEBSCRAPE
    airportMap.addConnection('Boston, MA', 'Las Vegas, NV', 345)
    airportMap.addConnection('Las Vegas, NV', "Los Angeles, CA", 143)

def getMap():
    airports = airportMap()
    dataDict = getData()
    locationDict = getLocations()

    for airport in dataDict:
        airports.addAirport(airport, locationDict[airport])

    createConnections(airports)

    return airports