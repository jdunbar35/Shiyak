# file: runFile.py
# author: Jack Dunbar
# date: 11/19/2017

from tkinter import *
from airportMap import *

def init(data):
    data.airPorts = airportMap()
    # Initialize airports

    data.background = PhotoImage(file="MapOfUS.png")
    data.x = 0
    data.deltaX = 24
    data.y = 0
    data.deltaY = 14
    data.scaleFactor = 1 # Implement Scale factor for zooming

    data.start = None
    data.finish = None

def keyPressed(event, data):
    if(event.keysym == "Left" and data.x >= data.deltaX):
        data.x -= data.deltaX
    elif(event.keysym == "Right" and data.x+data.width <= data.width-data.deltaX):
        data.x += data.deltaX
    elif(event.keysym == "Up" and data.y >= data.deltaY):
        data.y -= data.deltaY
    elif(event.keysym == "Down" and data.y+data.height <= data.height-data.deltaY):
        data.y += data.deltaY
    elif(event.keysym == "=" and data.scaleFactor < 1):
        data.scaleFactor += .1
    elif(event.keysym == "-" and data.scaleFactor > 0):
        data.scaleFactor -= .1

def mousePressed(event, data):
    # If near airport, it selects that airport for either takeoff or landing
    pass

def timerFired(data):
    # Only will be used from plan animation
    pass

def redrawAll(canvas, data):
    canvas.create_image(0-data.x, 0-data.y, image = data.background, anchor = "nw")

# Altered run function from 15-112 course notes:
# http://www.cs.cmu.edu/~112/notes
def runShiyak(width, height):
    def redrawAllWrapper(canvas, data):
        canvas.delete(ALL)
        canvas.create_rectangle(0, 0, data.width, data.height,
                                fill='white', width=0)
        redrawAll(canvas, data)
        canvas.update()

    def mousePressedWrapper(event, canvas, data):
        mousePressed(event, data)
        redrawAllWrapper(canvas, data)

    def keyPressedWrapper(event, canvas, data):
        keyPressed(event, data)
        redrawAllWrapper(canvas, data)

    def timerFiredWrapper(canvas, data):
        timerFired(data)
        redrawAllWrapper(canvas, data)
        # pause, then call timerFired again
        canvas.after(data.timerDelay, timerFiredWrapper, canvas, data)

    # Set up data and call init
    class Struct(object): pass
    data = Struct()
    data.width = width
    data.height = height
    data.timerDelay = 100  # milliseconds
    root = Tk()
    init(data)

    # create the root and the canvas
    canvas = Canvas(root, width=data.width, height=data.height)
    canvas.pack()

    # set up events
    root.bind("<Button-1>", lambda event:
    mousePressedWrapper(event, canvas, data))
    root.bind("<Key>", lambda event:
    keyPressedWrapper(event, canvas, data))
    timerFiredWrapper(canvas, data)
    # and launch the app
    root.mainloop()  # blocks until window is closed

def main():
    runShiyak(1200, 742)
    testDijkstras()

if __name__ == '__main__':
    main()