Hello and welcome to Shiyak!

The goal of this program is to help you find the cheapest way to fly from point a to point b.
It will allow you to simulate the cost of flying between any two large airports (> 1,000,000 departures annually) in the United States.

In order to run this program, you will need to have python 3.x installed as well as the 'requests' module.
To install the 'requests' module, go into your command prompt/terminal and type in 'pip install requests'.

In order to use the program, open shiyak.py in an IDE or run it in the terminal/command prompt.

Further instructions on interacting with shiyak can be found on the help screen of the program window.
